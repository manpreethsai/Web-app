<html>
<body>
<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connected<br>";
$var1=$_POST['tid'];
$var2=$_POST['doj'];
$sql1="select * from RESERVE where RESERVE.TID='$var1' and RESERVE.DT='$var2'";
$result1=mysqli_query($conn,$sql1);
$rows1=mysqli_num_rows($result1);
if(mysqli_num_rows($result1) > 0)
{
echo "<table>";
echo "<tr>"."<td>"."NAME"."</td>"."<td>"."EMAIL"."</td>"."<td>"."MOBILE"."</td>"."<td>"."TICKET ID"."</td>"."<td>"."BUS ID"."</td>"."<td>"."DATE OF JOURNEY"."</td>"."<td>"."SEAT NO"."</td>"."</tr>";
while($tuple1= mysqli_fetch_assoc($result))
{
   echo "<tr>"."<td>".$tuple1["NAME"]."</td>"."<td>".$tuple1["EMAIL"]."</td>"."<td>".$tuple1["MOBILE"]."</td>"."<td>".$tuple1["TID"]."</td>"."<td>".$tuple1["BID"]."</td>"."<td>".$tuple1["DT"]."</td>"."<td>".$tuple1["SEAT"]."</td>"."</tr>"; 
   $x = $tuple1["BID"];
}
}

$sql2="select * from BUS where BID='$x'";
$result2=mysqli_query($conn,$sql2);
if(mysqli_num_rows($result2) > 0)
{
echo "<table>";
echo "<tr>"."<td>"."FARE"."</td>"."<td>"."DEPARTUTE TIME"."</td>"."<td>"."ARRIVAL TIME"."</td>"."</tr>";
while($tuple2 = mysqli_fetch_assoc($result2))
{
    echo "<tr>"."<td>".$tuple2["FARE"]."</td>"."<td>".$tuple2["DEPTTIME"]."</td>"."<td>".$tuple2["ARRTIME"]."</td>"."</tr>";
}  
echo "</table>";
}

else
{
echo "<h3 align=center>"."Please enter valid details"."</h3>";
echo "<form action=ticket_details_form.php method=post enctype=multipart/form-data>
<table>
<tr><th><input type=submit value=RE-ENTER DETAILS></th></td></table>
</form>";
exit();
}
mysqli_close($conn);
}
?>

<form action="features.php" method="post" enctype="multipart/form-data">
<table>
<tr><th><input type="submit" value="bustickets.in_SERVICES"></th></td></table>
</form>
<br></br>
<form action="index1.php" method="post" enctype="multipart/form-data">
<p align="center" border="1px solid black"><input type="submit" value="LOGOUT_SESSION"></p>
</form>

<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee> 
</body>
</html>
