<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

p
{
font-size:25px;
}

</style>
</head>

<body>
<form action="reserve2.php" method="POST" enctype="multipart/form-data">
<p align="center">ORIGIN : <br>
 <select name="origin" required>
  <option value="hyderabad">HYDERABAD</option>
  <option value="bangalore">BANGALORE</option>
  <option value="chennai">CHENNAI</option>
</select> </p>

<p align="center">DESTINATION : <br>
 <select name="dest" required>
  <option value="hyderabad">HYDERABAD</option>
  <option value="bangalore">BANGALORE</option>
  <option value="chennai">CHENNAI</option>
</select> </p>

<p align="center">DATE OF JOURNEY :<br><input type="date" name="doj1" min="2015-11-08" placeholder="enter doj" required></p>
<p align="center"><input type="submit" value="SUBMIT" required></p>

</form>
</body>
</html>


















