

<?php
    ini_set('mysql.connect_timeout',300);
    ini_set('default_socket_timeout',300);
?>



<?php
session_start();
$seatno=26;
if(isset($_SESSION['bid2']) && isset($_SESSION['doj2']))
{
	
	$servername='localhost';
    $username='manpreeth';
    $password='manu';
    $dbname='bus_resv';
    $conn=mysqli_connect($servername,$username,$password,$dbname);
	if(mysqli_connect_errno())
	{
		echo "Connection to database failed.".mysqli_connect_error();
		exit();
	}
	else
	{
	//echo "connected";
	$count=0;
	
	$var1=$_SESSION['bid2'];
	$var2=$_SESSION['doj2'];
	$var3=$seatno;
	
	/*$_SESSION['selectbus2']=$var1;
	$_SESSION['doj2']=$var2;
	$_SESSION['seatno']=$var3;*/
	
	$sql= "select distinct SEAT from RESERVE where RESERVE.BID='$var1' AND RESERVE.DT='$var2' order by SEAT";
	$result=mysqli_query($conn,$sql);
	if(!$result)
	{
	echo "SOMETHING WRONG";
	}
	
    else
	{
	$rows=mysqli_num_rows($result);
	if(mysqli_num_rows($result) > 0 && mysqli_num_rows($result) < 27) 
    {
	 while($tuple=mysqli_fetch_assoc($result))
	 {
	  if($var3== $tuple['SEAT'])
	  { 
	   echo "<h1 align=center><p color=red>selected seat number is already booked</p></h1><h1 align=center>kindly press <a href=reserve1.php>here</a> to book ticket again</h1>";
	 
	 exit();
	   
	   }
	 }
	 
	 
	mysqli_close($conn);
	}
}
}
}
?>
<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(bus43.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;
}

#table1,tr,th,td
{
width:1000px;
border:2px groove black;
margin:0% 0% 0% 15%;
color:white;
size:25px;
}

#table2,tr,th,td
{
width:1000px;
border:2px groove black;
margin:0% 0% 0% 15%;
color:white;
size:25px;
}

p
{
margin:auto;
color:grey;


}
</style>
</head>

<body>
<form action="pass_details.php" method="POST" enctype="multipart/form-data"><br/>

<table id="table1">

<tr>
<th colspan=2><h2>PASSENGER ENTRY DETAILS</h2></th>
</tr>

<tr>
<td>1.NAME</td><br>
<td><input type="text" name="name" placeholder="enter your full name" required></td>
</tr>

<tr>
<td>2.EMAIL</td><br>
<td><input type="email" name="email" placeholder="username@server.domain" required></td>
</tr>

<tr>
<td>3.MOBILE</td><br>
<td><input type="text" name="mobile" placeholder="10 digit mobile number" pattern="[0-9]{10}" required></td>
</tr>
</table>

<table id="table2">
<tr>
<th colspan=2><h2>RESERVATION DETAILS</h2></th>
</tr>

<tr>
<td>1.TICKET ID (busid_seatno for eg:1001_10) :</td><br />
<td><input type="text" name="tid" value="<?php echo  $_SESSION['bid2']."_". $seatno;  ?>"  required</td>
</tr>

<tr>
<td>2.BUS_ID</td><br>
<td><input type="text" name="bid" value="<?php echo $_SESSION['bid2']; ?>" pattern="[0-9]{4}" required></td>
</tr>

<tr>
<td>3.DATE OF JOURNEY (dd-mm-yyyy) :</td><br />
<td><input type="date" name="journdate" min="2015-11-06" value="<?php echo $_SESSION['doj2']; ?>"  required</td>
</tr>

<tr>
<td>4.SEAT_NO</td><br />
<td><input type="number" name="seatnum" min="1" max="27" value="<?php echo $seatno; ?>" </td>
</tr>

</table>

<br><br>
<p align="center"><input type="submit" value="SUBMIT DETAILS"></p>
</form>
<br>
<br>
<br><br>
<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="250px" height="90px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="250px" height="90px"></h2></marquee>
</body>
</html>

                                                                                                                                                               