<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b4.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

table,tr,td,th
{
border:2px solid blue;
margin:1% 50% 0% 50%;
}

#id1
{
border:2px solid blue;
margin:5% 50% 0% 40%;
}

</style>
</head>

<body>

<?php
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
session_start();
//echo $_SESSION['bid2'];
$var1=$_SESSION["bid2"];
//echo $_SESSION['bid2'];
$var2=$_SESSION['doj2'];
$var3=$_POST['pass'];
$sql="SELECT SEAT FROM RESERVE WHERE BID='$var1' AND DT='$var2'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
$var4=27-$count;
if(!$result)
{
echo "ERROR1";
exit();
}

if($var3 > $var4)
{
echo "<h1 align=center style=color:red>REQUIRED NO.OF SEATS ARE NOT AVAILABLE</h1>";
echo "<form action=reserve2.php method=POST>
<p align=center><input type=submit value=CHECK_OTHER_BUSES></p></form>";
exit();
}

echo "<h1 align=center style=color:red>REQUIRED NO.OF SEATS ARE AVAILABLE<br>CLICK HERE TO SELECT THE REQUIRED SEAT</h1>";
}
?>

<table id=id1>
<th><img src="b6.jpg" height="300px" width="300px"></th>
</table>

<html>

<body>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part1_3.php" style="display:block;width:40px; height:25px; position:fixed; left:656px; top:282px;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part2_4.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:38.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part3_5.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:38.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part4_2.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:34%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part5_1.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:34%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part6_6.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:38.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part7_7.php" style="display:block;width:40px; height:25px; position:fixed; left:42.9%; top:42.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part8_8.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:42.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part9_9.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:42.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part10_10.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:42.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part14_11.php" style="display:block;width:40px; height:25px; position:fixed; left:42.9%; top:46.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part13_12.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:46.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part12_13.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:46.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part11_14.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:46.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part16_15.php" style="display:block;width:40px; height:25px; position:fixed; left:42.9%; top:50.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part15_16.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:50.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part17_17.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:50.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part18_18.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:50.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part22_19.php" style="display:block;width:40px; height:25px; position:fixed; left:42.9%; top:54.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part21_20.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:54.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part20_21.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:54.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part19_22.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:54.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part23_23.php" style="display:block;width:40px; height:25px; position:fixed; left:42.9%; top:58.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part24_24.php" style="display:block;width:40px; height:25px; position:fixed; left:45.9%; top:58.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part25_25.php" style="display:block;width:40px; height:25px; position:fixed; left:48.9%; top:58.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part26_26.php" style="display:block;width:40px; height:25px; position:fixed; left:52.2%; top:58.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<div class="flexslider">
<ul class="slides" runat="server" id="Ul">                             
    <li class="flex-active-slide" style="background:no-repeat scroll 0px transparent;float:left; margin-right:-100%;display:list-item;background-size:100%;">
        <div class="container">
        <div class="sixteen columns contain"></div>   
          <img runat="server" id="imgSlide1" style="top: 1px; right:-19px; opacity: 1;" class="item"  data-topimage="7%">
             <a href="part27_27.php" style="display:block;width:40px; height:25px; position:fixed; left:55.2%; top:58.4%;"></a>     
			 </div>   
                </li>
                </ul>
             </div>

            <ul class="flex-direction-nav">

                <li><a class="flex-prev" href="#"><i class="icon-angle-left"></i></a></li>
                <li><a class="flex-next" href="#"><i class="icon-angle-right"></i></a></li>
            </ul>           

</div>

<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="bus4.gif" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="bus4.gif" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="bus4.gif" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>



</body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           


