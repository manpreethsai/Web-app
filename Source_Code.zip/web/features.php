<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style text="text/css">
video#bgvid { 
    position: fixed;
    top: 50%;
    left: 50%;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: -100;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    background: url(polina.jpg) no-repeat;
    background-size: cover; 
}

table
{
border:1px solid black;
margin:40% 45% 0% 45%;
}
</style>
</head>

<body>
<video autoplay loop poster="bus16.jpg" id="bgvid">
    <source src="travel.webm" type="video/webm">
    <source src="travel.mp4" type="video/mp4">
</video>
<form action="index1.php" method="POST" enctype="multipart/form-data">
<table>
<tr><th><input type="submit" value="LOGOUT SESSION"></th></td></table>
</form>
</body>

</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          