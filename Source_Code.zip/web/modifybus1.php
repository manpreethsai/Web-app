<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

</style>
</head>
</html>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
echo "<form action=modifybus2.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=MODIFY_EXISTING_DETAILS></p>
</form>";
echo "<form action=modifybus4.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=ADD_NEW_DETAILS></p>
</form>";
echo "<form action=modifybus6.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=REMOVE_DETAILS></p><br><br><br>
</form>";
echo "<form action=index1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=LOGOUT_ADMIN_SESSION></p><br><br>
</form>";
}







?>
