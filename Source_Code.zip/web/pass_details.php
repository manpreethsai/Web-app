<html>

<head>
<title>bustickets.in</title>
<style type="text/css">

body{
  background-image:url(b10.jpg);
  background-position:0 0;
  background-repeat:no-repeat;
  background-size:100%;
  padding:7px 7 px 5px 0px;
  size:25px;
  }
  
table,tr,th,td
{
margin:5% 10% 0% 8%;
padding:7 25 7 25;
border:2px groove red;
color:black;
}

</style>
</head>

<body>
<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>

<?php
          
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);
$var1=$_POST['name'];
$var2=$_POST['email'];
$var3=$_POST['mobile'];
$var4=$_POST['tid'];
$var5=$_POST['bid'];
$var6=$_POST['journdate'];
$var7=$_POST['seatnum'];
if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connected<br>";		
$sql1= "INSERT INTO RESERVE(NAME,EMAIL,MOBILE,TID,BID,DT,SEAT) values ('$var1','$var2','$var3','$var4','$var5','$var6','$var7')";
$result1=mysqli_query($conn,$sql1);
//$row1=mysqli_num_rows($result1);
/*             
if (mysqli_query($conn,$sql1)) 
{
    echo "<h3 align=center>"."New passenger record created successfully"."</h3>";
} 
else
{
    echo "Error: ".$sql1."<br>".mysqli_error($conn);
	exit();
}*/
if(!$result1)
{
echo "<p id=wrong>WRONG CREDENTIALS OR EXISTING CREDENTIALS ENTERED.PLEASE ENTER CORRECT DETAILS</p>";
echo "<form id=wrong action=register5.php method=POST>
<input type=submit value=SELECT_AGAIN>
</form>";
exit();

}
else{
$sql2="SELECT * FROM RESERVE,BUS where RESERVE.TID='$var4' and RESERVE.DT='$var6' and RESERVE.BID=BUS.BID";
$result2=mysqli_query($conn,$sql2);
$row2=mysqli_num_rows($result2);

if(mysqli_num_rows($result2) > 0)
{
echo "<table>";
echo "<tr>"."<td>"."NAME"."</td>"."<td>"."EMAIL"."</td>"."<td>"."MOBILE"."</td>"."<td>"."TICKET ID"."</td>"."<td>"."BUS ID"."</td>"."<td>"."DATE OF JOURNEY"."</td>"."<td>"."SEAT NO"."</td>"."<td>"."FARE"."</td>"."<td>"."DEPARTURETIME"."</td>"."<td>"."ARRIVALTIME"."</td>"."</tr>";
while($tuple1= mysqli_fetch_assoc($result2))
{
   echo "<tr>"."<td>".$tuple1["NAME"]."</td>"."<td>".$tuple1["EMAIL"]."</td>"."<td>".$tuple1["MOBILE"]."</td>"."<td>".$tuple1["TID"]."</td>"."<td>".$tuple1["BID"]."</td>"."<td>".$tuple1["DT"]."</td>"."<td>".$tuple1["SEAT"]."</td>"."<td>".$tuple1["FARE"]."</td>"."<td>".$tuple1["DEPTTIME"]."</td>"."<td>".$tuple1["ARRTIME"]."</td>"."</tr>"; 
   
}

echo "</table>";
}
else
{
echo "<h2 align=center style=color:red>"."PLEASE ENTER VALID DETAILS"."</h2>";
}

mysqli_close($conn);   
}
}

?>


<form action="pay.php" method="POST" enctype="multipart/form-data" action="">
        <br/>
<p align="center"><input type="submit" value="PROCEED TO PAY" size="25px">
        </form>

</body>
</html>