<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(bus21.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
font-size:25px;
}

table
{
border:1px solid brown;
margin:15% 45% 0% 45%;
}
</style>
</head>

<body>
<?php
          
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connected<br>";
$var1=$_POST['tid'];
$var2=$_POST['doj'];
$sql1= "select * from RESERVE where RESERVE.TID='$var1' and RESERVE.DT='$var2'";
$result=mysqli_query($conn,$sql1);
$row=mysqli_num_rows($result);

if (mysqli_num_rows($result) > 0)
{
while($row = mysqli_fetch_assoc($result))
{
$sql2= "delete from RESERVE where RESERVE.TID='$var1' and RESERVE.DT='$var2' ";
if(mysqli_query($conn,$sql2))
{
echo "<h3 align=center>"."Your seat has been cancelled"."</h3>";
echo "<br>";
echo "<h3 align=center>"."Your amount will be credited in your account within two days.ThankYOu for using bustickets.in"."</h3>";
}

else 
{
echo "<h3 align=center>"."cannot delete"."</h3>";
}
}
} 

else 
{
    echo "<h3 align=center>"."Please enter valid details"."</h3>";
	echo "<form action=cancel.php method=post enctype=multipart/form-data>
<table>
<tr><th><input type=submit value=RE-ENTER DETAILS></th></td></table>
</form>";
exit();
}
mysqli_close($conn);
}

?>
<form action="features.php" method="post" enctype="multipart/form-data">
<table>
<tr><th><input type="submit" value="bustickets.in_SERVICES"></th></td></table>
</form>
<br></br>
<form action="index1.php" method="post" enctype="multipart/form-data">
<p align="center" border="1px solid black"><input type="submit" value="LOGOUT_SESSION"></p>
</form>

<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee> 

</body>
</html>

