<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

</style>
</head>
</html>


<?php
if(isset($_POST['admin']) && isset($_POST['pwd']))
{
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);
$var1=$_POST['admin'];
$var2=$_POST['pwd'];

if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
if(!($var1=="manpreeth" && $var2=="manu1996"))
{
echo "<h1 align=center style=color:red>SORRY.RE-ENTER ADMIN CREDENTIALS CORRECTLY OR LOGIN AS USER</h1>";
echo "<form action=admin12.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RELOGIN_AS_ADMIN></p>
</form>";
echo "<form action=userlogin12.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=LOGIN_AS_USER></p>
</form>";
}

else
{
echo "<form action=modifyroute1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=MODIFY_ROUTE_DETAILS></p>
</form>";
echo "<form action=modifybus1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=MODIFY_BUS_DETAILS></p>
</form>";
}
}


}



?>

<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

</style>
</head>
</html>