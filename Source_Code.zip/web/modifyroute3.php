<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
}

table,tr,td,th
{
border:2px groove black;
margin:5% 50% 0% 40%;
padding:5px 5px 5px 5px;
}

#id1
{
border:2px rigid white;
margin:0% 50% 0% 41%;
padding:3px 3px 3px 3px;
color:white;
}
</style>
</head>
</html>

<?php
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var0=$_POST["rid"];
$var1=$_POST["origin"];
$var2=$_POST["dest"];
$count=0;

if($var1==$var2)
{echo "ORIGIN AND DESTINATION CAN'T BE SAME";
}
else{

$sql1="SELECT RID FROM ROUTE";
$result1=mysqli_query($conn,$sql1);
$num1=mysqli_num_rows($result1);
if(mysqli_num_rows($result1) > 0)
{
while($row1=mysqli_fetch_assoc($result1))
{
$var4=$row1['RID'];

if($var0 == $var4)
{
break;

}
else
{
++$count;
continue;
}
}
if($count==$num1)
{
echo "<h1 align=center style=color:red>ENTER EXISTING RID !!</h1>";
echo "<form action=modifyroute2php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}
$sql2="UPDATE ROUTE SET ORIGIN='$var1',DESTINATION='$var2' WHERE RID='$var0'";
$result2=mysqli_query($conn,$sql2);
$sql3="SELECT * FROM ROUTE";
$result3=mysqli_query($conn,$sql3);
if(mysqli_num_rows($result3)>0)
{
echo "<table>";
echo "<tr><th>ROUTE_ID</th><th>ORIGIN</th><th>DESTINATION</th></tr>";
while($row=mysqli_fetch_assoc($result3))
{
echo "<tr><td>".$row['RID']."</td><td>".$row['ORIGIN']."</td><td>".$row['DESTINATION']."</td></tr>";

}
echo"</table>";
}
echo "<form action=modifyroute1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=BACK_TO_MODIFY_ROUTE></p><br><br>
</form>";

}
}
}
?>

