<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
}

table,tr,td,th
{
border:2px groove black;
margin:1% 50% 0% 40%;
padding:5px 5px 5px 5px;
}

#id1
{
border:2px rigid white;
margin:0% 50% 0% 41%;
padding:3px 3px 3px 3px;
color:white;
}
</style>
</head>
</html>

<?php
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var0=$_POST["bid"];
$var1=$_POST["rid"];
$var2=$_POST["fare"];
$var3=$_POST["dep"];
$var4=$_POST["arr"];
$count=0;



$sql1="SELECT BID FROM BUS";
$result1=mysqli_query($conn,$sql1);
$num1=mysqli_num_rows($result1);
if(mysqli_num_rows($result1) > 0)
{
while($row1=mysqli_fetch_assoc($result1))
{
$var6=$row1['BID'];

if($var0 == $var6)
{
break;

}
else
{
++$count;
continue;
}
}
if($count==$num1)
{
echo "<h1 align=center style=color:red>ENTER EXISTING RID !!</h1>";
echo "<form action=modifyroute2php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}
$sql2="UPDATE BUS SET RID='$var1',FARE='$var2',DEPTTIME='$var3',ARRTIME='$var4' WHERE BID='$var0'";
$result2=mysqli_query($conn,$sql2);
$sql3="SELECT * FROM BUS";
$result3=mysqli_query($conn,$sql3);
if(mysqli_num_rows($result3)>0)
{
echo "<table>";
echo "<tr><th>BUD_ID</th><th>ROUTE_ID</th><th>FARE</th><th>DEPTTIME</th><th>ARRTIME</th></tr>";
while($row=mysqli_fetch_assoc($result3))
{
echo "<tr><td>".$row['BID']."</td><td>".$row['RID']."</td><td>".$row['FARE']."</td><td>".$row['DEPTTIME']."</td><td>".$row['ARRTIME']."</td></tr>";

}
echo"</table>";
}
echo "<form action=modifybus1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=BACK_TO_MODIFY_BUS></p><br><br>
</form>";

}
}

?>

