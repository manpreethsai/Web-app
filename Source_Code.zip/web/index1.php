<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style text="text/css">
video#bgvid { 
    position: fixed;
    top: 50%;
    left: 50%;
    min-width: 100%;
    min-height: 100%;
    width: auto;
    height: auto;
    z-index: -100;
    -webkit-transform: translateX(-50%) translateY(-50%);
    transform: translateX(-50%) translateY(-50%);
    background: url(polina.jpg) no-repeat;
    background-size: cover; 
	size:20px;
}

#id1
{
border:1px solid blue;
margin:5% 45% 0% 45%;
}

#id2
{
border:1px solid blue;
margin:2% 45% 0% 45%;
}
</style>
</head>

<body>
<video autoplay loop poster="bus8.jpg" id="bgvid">
    <source src="web2.webm" type="video/webm">
    <source src="web2.mp4" type="video/mp4">
</video>
<form action="register1.php" method="POST" enctype="multipart/form-data">
<table id="id1">
<tr><th><input type="submit" value="REGISTER TO WEBSITE"></th></td></table>
</form>

<form action="userlogin12.php" method="POST" enctype="multipart/form-data">
<table id="id2">
<tr><th><input type="submit" value="LOGIN TO THE WEBSITE"></th></td></table>
</form>

<form action="admin12.php" method="POST" enctype="multipart/form-data">
<table id="id2">
<tr><th><input type="submit" value="ADMIN LOGIN TO WEBSITE"></th></td></table>
</form>
</body>

</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 