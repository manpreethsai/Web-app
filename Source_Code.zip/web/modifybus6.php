<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

table,tr,td,th
{
border:2px groove black;
margin:5% 50% 0% 40%;
padding:5px 5px 5px 5px;
}

table#id1
{

margin:3% 50% 0% 41%;
padding:3px 3px 3px 3px;
color:white;
}



</style>
</head>
</html>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$sql="SELECT * FROM BUS";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
echo "<table>";
echo "<tr><th>BUD_ID</th><th>ROUTE_ID</th><th>FARE</th><th>DEPTTIME</th><th>ARRTIME</th></tr>";
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td>".$row['BID']."</td><td>".$row['RID']."</td><td>".$row['FARE']."</td><td>".$row['DEPTTIME']."</td><td>".$row['ARRTIME']."</td></tr>";


}
echo"</table>";
echo "<table id=id1>";
echo "<form action=modifybus7.php method=POST enctype=multipart/form-data>

<tr><p align=center style=color:red><td>BID: </td><td><input type=number name=bid placeholder=enter_rid  pattern=[0-9]{4} required></p></td></tr>
<tr><p align=center style=color:red><td>RID: </td><td><input type=text name=rid placeholder=enter_origin pattern=[0-9]{3} required></p></td></tr>
<tr><p align=center style=color:red><td>FARE: </td><td><input type=text name=fare placeholder=enter_origin required></p></td></tr>
<tr><p align=center style=color:red><td>DEPTTIME: </td><td><input type=text name=dep placeholder=enter_origin pattern=[0-9]{2}+:+[0-9]{2} required></p></td></tr>
<tr><p align=center style=color:red><td>ARRTIME: </td><td><input type=text name=arr placeholder=enter_destination pattern=[0-9]{2}+:+[0-9]{2} required></p></tr><br><br>
<tr><p align=center style=color:red><th colspan=2><input type=submit value=MODIFY_BUS_DETAILS></p></th>
</form>";

echo "</table>";

}
}
?>

