<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$sql="SELECT * FROM ROUTE";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
echo "<table>";
echo "<tr><th>ROUTE_ID</th><th>ORIGIN</th><th>DESTINATION</th></tr>";
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td>".$row['RID']."</td><td>".$row['ORIGIN']."</td><td>".$row['DESTINATION']."</td></tr>";

}
echo"</table>";
echo "<form action=modifyroute2.php method=POST enctype=multipart/form-data>
<p align=center style=color:red>RID: <input type=number name=rid placeholder=enter_rid  pattern=[0-9]{3} required></p>
<p align=center style=color:red>NEW ORIGIN: <input type=text name=origin placeholder=enter_origin required></p>
<p align=center style=color:red>NEW DESTINATION: <input type=text name=dest placeholder=enter_destination required></p>
<p align=center style=color:red><input type=submit value=MODIFY_ROUTE_DETAILS></p>
</form>";

}
}
?>