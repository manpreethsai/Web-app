<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b7.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}





</style>
</head>

<body>
<img src="b6.jpg" height="300px" width="300px"><br>
<h1 style="color:white">CHECK THE AVAILABILITY OF SEATS OVER HERE</h1><br><br>
<form action="reserve4.php" method="POST" enctype="multipart/form-data"><br>
<table>
<tr><td><p align="center" style="color:red;size:25px;">BUS_ID : </p></td><td><input type="text" name="bid2" value="<?php  echo $_POST['bid']; ?>" readonly></td></tr>
<tr><td><p align="center" style="color:red;size:25px;">JOURNEY_DATE : </p></td><td><input type="date" name="doj2" min="2015-11-08" value="<?php session_start(); echo $_SESSION['doj1']; ?>" readonly></td></tr>
<tr><td></td></tr>
<tr><td><p align="center"><input type="submit" value="CHECK_SEATS"></p></td></tr>
</table>
</form>

</body>
</html>

