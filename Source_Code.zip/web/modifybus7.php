<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

table,tr,td,th
{
border:2px groove black;
margin:5% 50% 0% 40%;
padding:5px 5px 5px 5px;
}

table#id1
{

margin:3% 50% 0% 41%;
padding:3px 3px 3px 3px;
color:white;
}



</style>
</head>
</html>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var0=$_POST["bid"];
$var1=$_POST["rid"];
$var2=$_POST["fare"];
$var3=$_POST["dep"];
$var4=$_POST["arr"];

if($var3==$var4)
{
echo "ORIGIN AND DESTINATION TIME CAN'T BE SAME";
exit();
}
else{

$sql1="SELECT * FROM BUS";
$result1=mysqli_query($conn,$sql1);
$count1=mysqli_num_rows($result1);
if($count1>0)
{
$manu=0;
while($row1=mysqli_fetch_assoc($result1))
{
$var5=$row1["BID"];
$var6=$row1["RID"];
$var7=$row1["FARE"];
$var8=$row1["DEPTTIME"];
$var9=$row1["ARRTIME"];

if(!($var0==$var5 && $var1==$var6 && $var2==$var7 && $var3==$var8 && $var4==$var9))
{
++$manu;

}

else
{
continue;
}

}
if($manu==$count1)
{
echo "<h1 align=center style=color:red>ENTER EXISTING VALID DETAILS</h1>";
echo "<form action=modifyroute6.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}

$sql2="DELETE FROM BUS WHERE BID='$var0'";
$result2=mysqli_query($conn,$sql2);
$sql3="SELECT * FROM BUS";
$result3=mysqli_query($conn,$sql3);

//$countn=mysqli_num_rows($resultn);
$count3=mysqli_num_rows($result3);
if($count3>0)
{
echo "<table>";
echo "<tr><th>BUD_ID</th><th>ROUTE_ID</th><th>FARE</th><th>DEPTTIME</th><th>ARRTIME</th></tr>";
while($row2=mysqli_fetch_assoc($result3))
{
echo "<tr><td>".$row2['BID']."</td><td>".$row2['RID']."</td><td>".$row2['FARE']."</td><td>".$row2['DEPTTIME']."</td><td>".$row2['ARRTIME']."</td></tr>";


}
echo"</table>";
echo "<form action=modifybus1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=BACK_TO_MODIFY_ROUTE></p><br><br>
</form>";
}
}
}
}
?>
