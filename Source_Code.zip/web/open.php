<!DOCTYPE html>
<html>
<head>
 <title>bustickets.in</title>
 <style type="text/css">
  body{
  
  background-image:url("b4.jpg");
  background-position:0 0px;
  background-repeat:repeat-x;
  background-size:100%;
  margin:0px 0px 50px 0px; 
  }
  
  h1{
    text-align:center;
	color:black;
	background-color:red;
 }	
  
  button{
  text-align:center;
  font-size:20px;
  border:2px solid black;
  padding: 7px 7px 7px 7px;
  margin: auto;
  background-position:10px 50px;
  
  }
 
  </style>
</head>

<body>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);

if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";

$var1=$_POST['admin'];
$var2=$_POST['pwd'];
$sql="SELECT * FROM REGISTER WHERE REGISTER.USERNAME='$var1' and REGISTER.PASSWORD='$var2'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result) == 0)
{
echo "<h1 align=center color=white>.INCORRECT CREDENTIALS.TRY AGAIN !!!.</h1>";
echo "<form action=userlogin12.php method=post enctype=multipart/form-data>
<p align=center><input type=submit value=RE-ENTER DETAILS></p>
</form>";
exit();
}



else
{
echo "<h1>WELCOME TO bustickets.in</h1><br />";
echo "<img src=b5.jpg height=330px width=100%>";
echo "<p align=center><button type=button onclick=window.location.href='reserve1.php' onmouseover=style.color='blue' onmouseout=style.color='black' onmousedown=style.color='yellow' onmouseup=style.color='black'>RESERVATION</button></p>
   <p align=center><button type=button onclick=window.location.href='cancel.php' onmouseover=style.color='blue' onmouseout=style.color='black' onmousedown=style.color='yellow' onmouseup=style.color='black'>CANCELLATION</button></p>
   <p align=center><button type=button onclick=window.location.href='ticket_details_form.php' onmouseover=style.color='blue' onmouseout=style.color='black' onmousedown=style.color='yellow' onmouseup=style.color='black'>TICKET DETAILS</button></p>
<marquee behavior=scroll direction=left><h2 style=color:yellow><img src=b5.jpg width=200px height=75px>BOOK YOUR TICKETS AT <span style=color:red>bustickets.in</span><img src=b5.jpg width=200px height=75px>BOOK YOUR TICKETS AT <span style=color:red>bustickets.in</span><img src=b5.jpg width=200px height=75px>BOOK YOUR TICKETS AT <span style=color:red>bustickets.in</span></h2></marquee>";
}
}



?> 

 </body>
</html>
