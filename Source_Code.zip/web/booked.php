<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

p
{
font-size:25px;
}

</style>
</head>

<body>
<h1 align="center">THANKYOU FOR USING OUR SERVICES AT bustickets.in.YOUR TRANSACTION WAS SUCCESSFUL.PLEASE VISIT AGAIN !!!! </h1>

<form action="features.php" method="POST"><br>
<p align="center"><input type=submit value="FEATURES_bustickets.in"></p>
</form>

</body>