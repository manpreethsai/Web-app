<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body{
  background-color:black;
  background-image:url(b3.jpg);
  background-size:100%;
  padding:7px 7 px 5px 0px;
  color:black;
  font-size:20px;
  }
  
  h3
  {
  text-align:center;
  color:black;
  background-color:grey;
  }
  
</style>
</head>

<body>
<h3>WELCOME TO bustickets.in</h3>
<form action="register2.php" method="POST" enctype="multipart/form-data"><br/>
   
   <p align="center">USERNAME:<br />
    <input type="text" name="usrname" placeholder="enter username" required></p>
   
    <p align="center">PASSWORD:<br />
    <input type="password" name="psswd" placeholder="enter password" pattern="[a-zA-Z0-9]{8}" required></p>
   
     <p align="center">EMAIL:<br />
   <input type="email" name="email" placeholder="username@host.domain"  required></p>
   
      <p align="center">MOBILE:<br />
   <input type="text" name="mob" placeholder="enter 10 digit number" pattern="[0-9]{10}" required></p>
   
   <p align="center">
   <input type="submit" value="REGISTER" style="size:20px;"></p>
   
</form>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  