<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

p
{
font-size:25px;
}

</style>
</head>

<body>
<form action="booked.php" method="POST" enctype="multipart/form-data">

<p align="center">NAME ON CARD:<br><input type="text" name="doj1"  placeholder="enter name" required></p>
<p align="center">ACCOUNT NUMBER :<br><input type="text" name="doj1" pattern="[0-9]{10}" placeholder="enter acno" required></p>
<p align="center">CARD NUMBER :<br><input type="text" name="doj1"  pattern="[0-9]{16}" placeholder="enter cardno" required></p>
<p align="center">EXPIRY DATE:<br><input type="date" name="doj1" min="2015-11-08" placeholder="enter doj" required></p>
<p align="center">CVV :<br><input type="text" name="doj1"  pattern="[0-9]{3}" placeholder="enter cvv" required></p>
<p align="center">MOBILE NUMBER :<br><input type="text" pattern="[0-9]{10}" placeholder="enter mobile no." required></p>
<p align="center"><input type="submit" value="SUBMIT" required></p>

</form>
</body>
</html>


















