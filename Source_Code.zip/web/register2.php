<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body{
  background-color:black;
  background-image:url(b3.jpg);
  background-size:100%;
  padding:7px 7 px 5px 0px;
  color:black;
  font-size:20px;
  }
  
  h3
  {
  text-align:center;
  color:black;
  background-color:grey;
  }
  
</style>
</head>

<body>

</body>
</html>

<?php


$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var1=$_POST['usrname'];
$var2=$_POST['psswd'];
$var3=$_POST['email'];
$var4=$_POST['mob'];

$sql1="INSERT INTO REGISTER VALUES ('$var1','$var2','$var3','$var4')";
$result1=mysqli_query($conn,$sql1);


if(!$result1)
{

echo "<h1 align=center style=color:red>WRONG CREDENTIALS OR EXISTING CREDENTIALS ENTERED !! </h1>";
echo "<form action=register1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=REGISTER_AGAIN></p><br><br>
</form>";
exit();
}

else{

echo "<h1 align=center style=color:green>THANKYOU FOR REGISTERING IN bustickets.in !! </h1>";
echo "<form action=userlogin1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=LOGIN_AS_USER></p><br><br>
</form>";
}
mysqli_close($conn);
}
?>



                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  