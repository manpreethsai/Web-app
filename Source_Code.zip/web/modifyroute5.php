<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

table,tr,td,th
{
border:2px groove black;
margin:5% 50% 0% 40%;
padding:5px 5px 5px 5px;
}





</style>
</head>
</html>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var1=$_POST["rid"];
$var2=$_POST["origin"];
$var3=$_POST["dest"];

if($var2==$var3)
{
echo "ORIGIN AND DESTINATION CAN'T BE SAME";
echo "<form action=modifyroute4.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}

$sql1="SELECT * FROM ROUTE";
$result1=mysqli_query($conn,$sql1);
$count1=mysqli_num_rows($result1);
if($count1>0)
{
while($row1=mysqli_fetch_assoc($result1))
{
$var4=$row1["RID"];
$var5=$row1["ORIGIN"];
$var6=$row1["DESTINATION"];
if($var1==$var4)
{
echo "<h1 align=center style=color:red>ENTER NON_EXISTING VALID DETAILS</h1>";
echo "<form action=modifyroute4.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}

else
{
continue;
}
}

$sql="SELECT * FROM ROUTE";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count>0)
{
while($row=mysqli_fetch_assoc($result))
{
$var7=$row["ORIGIN"];
$var8=$row["DESTINATION"];
if($var2==$var7 && $var3==$var8)
{
echo "<h1 align=center style=color:red>ENTER NON_EXISTING VALID DETAILS</h1>";
echo "<form action=modifyroute4.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=RE-ENTER_DETAILS></p>
</form>";
exit();
}

else
{
continue;
}
}
}

$sql2="INSERT INTO ROUTE VALUES ('$var1','$var2','$var3')";
$result2=mysqli_query($conn,$sql2);
$sql3="SELECT * FROM ROUTE";
$result3=mysqli_query($conn,$sql3);
$count3=mysqli_num_rows($result3);
if($count3>0)
{
echo "<table>";
echo "<tr><th>ROUTE_ID</th><th>ORIGIN</th><th>DESTINATION</th></tr>";
while($row2=mysqli_fetch_assoc($result3))
{
echo "<tr><td>".$row2['RID']."</td><td>".$row2['ORIGIN']."</td><td>".$row2['DESTINATION']."</td></tr>";

}
echo"</table>";
echo "<form action=modifyroute1.php method=POST enctype=multipart/form-data>
<p align=center style=color:red><input type=submit value=BACK_TO_MODIFY_ROUTE></p><br><br>
</form>";
}
}
}

?>


