<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>bustickets.in</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
/*body
{
background-image:url(b1.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;
margin:12% 50% 0% 45%;
}

table
{
border:2px groove white;
margin:5% 60% 0% 5%;

}*/

</style>
</head>
<body>
	<div class="banner">
		<div class="wrap">
			<div class="logo">
				<img src="b43.png">
			</div>
			<p>be sure you put your feet </br> <span>in the right place</span></p>
		</div>
	</div>
	<!--<div class="content">
		<div class="wrap">
			<div class="searching">
				<div class="main">
					<div class="ui-widget">
						  <input type="text" id="tags" value="Enter Your Zip Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Your Zip Code';}">
					</div>-->
					<div class="images">
						<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="web/images/b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="web/images/b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="web/images/b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>
					</div>
					
					<!--<div class="brows_button_3">
							<a href="#">PROCEED</a>
					</div>-->
				</div>
			</div>
			<!-----suggetion-script----------->
			 <script src="web/js/jquery.min.js"></script>
 			 <script src="web/js/jquery-ui.js"></script>
 			  <script>
			  $(function() {
			    var availableTags = [
			      "123456",
			      "343546",
			      "374835",
			      "564668",
			      "545425",
			      "449235",
			    ];
			    $( "#tags" ).autocomplete({
			      source: availableTags
			    });
			  });
			  </script>
 			 <!-----end-suggetion-script------->
			<!--<div class="grids">
				<div class="grid_of_1">
					<img src="web/images/g2.png">
					<div class="desc">
						<h3>Lorem ipsum dolor sit.</h3>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry,It is a long established.</p>
					</div>
					<div class="clear"> </div>
				</div>-->
				<!--<div class="grid_of_1">
					<img src="web/images/g1.png">
					<div class="desc">
						<h3>Lorem ipsum dolor sit.</h3>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry,It is a long established.</p>
					</div>-->
					<div class="clear"> </div>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="tab">
				<div class="wrap">
					<div class="group_1">
						<div class="shadow">
							<img src="web/images/im.png">
						</div>
						<div class="desc-1">
								<h4>bustickets.in @ ALSO AVAILABLE ON TABLETS</h4>
								<div class="para">
									<p></p>
								</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>
			<div class="monitor">
				<div class="wrap">
					<div class="group_2">
						<div class="img_of_monitor">
							<img src="web/images/im2.png">
						</div>
						<div class="para_1">
								<h4>ENTER DETAILS</h4>
								<p>
								<table>
<form action="forgot2.php" method="POST" enctype="multipart/form-data">

<tr><td>USERNAME: </td><td><input type="text" name="admin" placeholder="username"></td></tr>
<tr><td>PASSWORD: </td><td><input type="password" name="pwd" placeholder="password"></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
<th colspan=2><div class="button"><a href="#" class="da-link"><span><input type="submit" value="LOGIN AS USER"> </span></a></div></th>
<tr><td></td></tr>
<tr><td></td></tr>


</form>

<form action="register1.php" method="POST" enctype="multipart/form-data"><br><br>
<!--<tr><th colspan=2><br><br><br><br>NOT REGISTERED??</th>
<tr><th colspan=2><div class="button"><a href="#" class="da-link"><span><input type="submit" value="REGISTER_HERE"> </span></a></div></th></tr>-->
</table>
</form> </p>
								<!--<div class="button">
									<a href="#" class="da-link"><span> Download</span></a>
								</div>-->
						</div>
						<div class="clear"> </div>
					</div>
				</div>
			</div>
	</div>
	<div class="contact">
		<div class="map">
			<iframe width="100%" height="650" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/?ie=UTF8&amp;ll=22.593726,79.453125&amp;spn=3.803105,6.696167&amp;t=m&amp;z=8&amp;output=embed"></iframe>
		</div>
		<!--<div class="form">
			<input type="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
			<input type="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'email address';}">
			<textarea  placeholder="Message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}"> Message</textarea>
			<a href="#"><span><img src="web/images/send.png" alt=" "/> </span></a>
		</div>-->
	</div>
	<div class="copy">
				       <p>&copy;<a href="#" target="_blank">bustickets.in</a></p>
			  </div>
</body>
</html>