<!DOCTYPE html>

<html>
<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b3.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
font-size:25px;
}

table,tr,th
{
margin:7% 50% 0% 40%;
padding:10 50 10 500;
border:2px groove brown;
color:white;

}
</style>
</head>

<body>
<form action="new.php" method="post" enctype="multipart/form-data"><br/>

<table>
<tr>
<th colspan=2>ENTER THE TICKET DETAILS <th>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td>TICKET ID</td>
<td><input type="text" name="tid" placeholder="enter TID" pattern="[0-9]{4}+_+[0-9]{2}" required > </td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td>DATE OF JOURNEY</td>
<td><input type="date" name="doj" placeholder="enter journey date" required></td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<th colspan=2><input type="submit" name="sumit" value="GET_DETAILS"></th>
</tr>

</table>

</form>
<p align="center" color="red"><a href="forgot1.php">FORGOT PASSWORD????</a></p>
<br><br><br><br>
<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>
</body>
</html>
