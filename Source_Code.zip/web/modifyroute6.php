<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b2.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;

}

table,tr,td,th
{
border:2px groove black;
margin:5% 50% 0% 40%;
padding:5px 5px 5px 5px;
}

table#id1
{

margin:3% 50% 0% 41%;
padding:3px 3px 3px 3px;
color:white;
}



</style>
</head>
</html>

<?php

$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);


if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$sql="SELECT * FROM ROUTE";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
echo "<table>";
echo "<tr><th>ROUTE_ID</th><th>ORIGIN</th><th>DESTINATION</th></tr>";
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td>".$row['RID']."</td><td>".$row['ORIGIN']."</td><td>".$row['DESTINATION']."</td></tr>";

}
echo"</table>";
echo "<table id=id1>";
echo "<form action=modifyroute7.php method=POST enctype=multipart/form-data>
<tr><td><p align=center style=color:white>RID: </p></td><td><input type=number name=rid placeholder=enter_rid  pattern=[0-9]{3} required></td></tr>
<tr><td><p align=center style=color:white>ORIGIN: </p></td><td><input type=text name=origin placeholder=enter_origin required></td></tr>
<tr><td><p align=center style=color:white>DESTINATION: </p></td><td><input type=text name=dest placeholder=enter_destination required></td></tr>
<th colspan=2><p align=center style=color:red><input type=submit value=MODIFY_ROUTE_DETAILS></p></th>
</form>";

echo "</table>";

}
}
?>