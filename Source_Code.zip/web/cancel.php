<!DOCTYPE html>


<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(bus20.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
font-size:25px;
}

table,th,tr
{
margin:7% 50% 0% 40%;
padding:10 50 10 500;
border:2px groove brown;

}
</style>

</head>

<body>
<form action="delete.php" method="post" enctype="multipart/form-data"><br/>
<table>

<tr>
<th colspan=2> ENTER THE DETAILS TO CANCEL </th>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td>TICKET ID</td>
<td><input type="text" name="tid" placeholder="enter tid as bid_seatno" required></td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td>DATE OF JOURNEY</td>
<td><input type="date" name="doj" placeholder="enter journey date" required></td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td></td>
</tr>
<button 
<tr>
<th colspan=2><a href="cancel_form.php" 
    onclick="return confirm('Re-check the entries & confirm !!!!');"><input type="submit" value="CANCEL"></a></th>
</tr>



</table>
</form>
<p align="center"><a href="forgot11.php">FORGOT PASSWORD????</a></p>
<br></br>
<br>
<marquee behavior="scroll" direction="left"><h2 style="color:black"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>
 

</body>
</html>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               