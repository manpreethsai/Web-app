<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b9.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;
}

table,tr,td,th
{
border:2px groove black;
margin:4% 50% 0% 45%;
color:white
}

</style>
</head>

<body>
<!--<img src="b6.jpg" height="300px" width="300px"><br>-->
<?php
$servername='localhost';
$username='manpreeth';
$password='manu';
$userdb='bus_resv';

$conn=mysqli_connect($servername,$username,$password,$userdb);
if(!$conn)
{
echo "not connected";
exit();
}
else
{
//echo "connected";
session_start();
$var1=$_POST["bid2"];
$var2=$_POST["doj2"];
$_SESSION["bid2"]=$var1;
$_SESSION["doj2"]=$var2;
$sql="SELECT SEAT FROM RESERVE WHERE BID='$var1' AND DT='$var2'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
$var=27-$count;
if(!$result)
{
echo "ERROR1";
exit();
}

if(mysqli_num_rows($result)>0 && mysqli_num_rows($result)<=26)
{

echo "<h2 align=center>NO.OF SEATS AVAILABLE='$var'</h2>";
echo "<table>";
echo "<th>SEAT_NUMBERS</th>";
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td align=center>".$row["SEAT"]."</td></tr>";
}
echo "<form action=reserve5.php method=POST>
<p align=center>NO.OF PASSENGERS :<input type=number name=pass min=1 max=$var placeholder=enter no.of passengers required>
<p align=center><input type=submit value=BOOK_NOW></p></form>";
}

else if(mysqli_num_rows($result)==0)
{
echo "<h1 align=center style=color:red border:1px solid red>NO SEATS ARE BOOKED YET</h1>";
echo "<h2 align=center>NO.OF SEATS AVAILABLE='$var'</h2>";
echo "<form action=reserve5.php method=POST>
<br><p align=center style=size:25px>NO.OF PASSENGERS :<input type=number name=pass min=1 max=27 placeholder=enter_no.of_passengers_required></p>
<br><p align=center><input type=submit value=BOOK_NOW></p></form>";
} 

else
{
echo "<h1 align=center style=color:red>NO SEATS AVAILABLE.PLEASE TRY LATER</h1>";
echo "<form action=reserve2.php method=POST>
<p align=center><input type=submit value=CHECK_OTHERS></p></form>";
exit();
}

}
?>

<!--<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<marquee behavior="scroll" direction="left"><h2 style="color:yellow"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>-->
</body>
</html>