<!DOCTYPE html>

<html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b1.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;
margin:12% 50% 0% 45%;
}

table
{
border:2px groove white;
margin:5% 60% 0% 5%;

}

</style>
</head>

<body>
<table>
<form action="admin2.php" method="POST" enctype="multipart/form-data">

<tr><td>USERNAME: </td><td><input type="text" name="admin" placeholder="admin"></td></tr>
<tr><td>PASSWORD: </td><td><input type="password" name="pwd" placeholder="password"></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
<th colspan=2><input type="submit" value="LOGIN AS ADMIN"></th>
<tr><td></td></tr>
<tr><td></td></tr>


</form>

<form action="login1.php" method="POST" enctype="multipart/form-data"><br><br>
<tr><td><h3 align="center" style="color:red">NOT AN ADMIN?? </h3></td><td><input type="submit" value="LOGIN AS USER"></td></tr>
</table>
</form>

</body>
</html>