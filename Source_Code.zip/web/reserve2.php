<!DOCTYPE html>

<head>
<title>bustickets.in</title>
<style type="text/css">
body
{
background-image:url(b10.jpg);
background-position:0 0;
background-repeat:no-repeat;
background-size:100%;
size:25px;
color:black;

}

table,tr,td,th
{
border:4px groove black;
margin:10% 40% 0% 10%;
padding:2px 2px 2px 2px;
width:80%;
height:40%;
font-size:20px;


}

</style>
</head>

<body>

<?php
$servername='localhost';
$username='manpreeth';
$password='manu';
$dbname='bus_resv';
$conn=mysqli_connect($servername,$username,$password,$dbname);

if(mysqli_connect_errno())
{
echo "not connected";
exit();
}
else
{
//echo "connection successful";
$var1=$_POST['origin'];
$var2=$_POST['dest'];
$var3=$_POST['doj1'];

session_start();
$_SESSION['doj1']=$var3;

if($var1==$var2)
{
echo "<h1 align=center style=color:red>ORIGIN AND DESTINATION CAN'T BE SAME</h1><br>";
echo "<form action=reserve1.php method=POST>
<p align=center><input type=submit value=RE-ENTER_DETAILS>,/p></form>";
}
else{
$sql="SELECT * FROM BUS WHERE RID=(SELECT RID FROM  ROUTE WHERE  ORIGIN='$var1' AND DESTINATION='$var2')";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count>0)
{
    echo "<h2>NUMBER OF ROUTES :$count</h2>";
	echo "<table>";
	echo "<th colspan=1>"."BUS ID"."</th>"."<th colspan=1>"."ROUTE ID"."</th>"."<th colspan=1>".""."FARE</th>"."<th colspan=1>"."DEPARTURE TIME"."</th>"."<th colspan=1>"."ARRIVAL TIME"."</th>";
	while($row=mysqli_fetch_assoc($result))
	{
		echo "<tr>"."<td>"."<form action=reserve3.php method=POST> <input type=text name=bid value=".$row["BID"]." readonly><input type=submit value=CHECK_AVAILABILITY></form>"."</td>"."<td>".$row["RID"]."</td>"."<td>".$row["FARE"]."</td>"."<td>".$row["DEPTTIME"]."</td>"."<td>".$row["ARRTIME"]."</td>"."</tr>";
	
	}
	echo "</table>";
}
else{
echo "<h1 align=center style=color:red>NO SUCH ROUTE EXISTS IN OUR SERVICES</h1>";
echo "<form action=reserve1.php method=POST>
<p align=center><input type=submit value=RE-ENTER_DETAILS></p></form>";
}


}
}

?>
<br><br><br><br><br><br><br><br><br><br><br><br>
<marquee behavior="scroll" direction="left"><h2 style="color:yellow"><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span><img src="b5.jpg" width="200px" height="75px">BOOK YOUR TICKETS AT <span style="color:red">bustickets.in</span></h2></marquee>
</body>
</html>